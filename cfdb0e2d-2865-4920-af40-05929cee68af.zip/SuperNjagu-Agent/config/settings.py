"""
SuperNjagu Agent - Configuration Settings
"""

import os
from typing import Dict, List


class Settings:
    """Application settings"""
    
    # Agent Configuration
    AGENT_NAME = "SuperNjagu Agent"
    AGENT_VERSION = "1.0.0"
    WORKSPACE = os.getenv("WORKSPACE", "/workspace")
    
    # Timeout Settings
    COMMAND_TIMEOUT = 300
    WEB_REQUEST_TIMEOUT = 30
    TASK_TIMEOUT = 600
    
    # Web Settings
    USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    MAX_SEARCH_RESULTS = 10
    
    # File Settings
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
    ALLOWED_FILE_TYPES = ['.txt', '.py', '.js', '.json', '.csv', '.xml', '.md']
    
    # Logging
    LOG_LEVEL = "INFO"
    LOG_FILE = "supernjagu.log"
    
    # Autonomous Mode
    AUTO_SAVE_INTERVAL = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 5
    
    # GitHub Settings
    GITHUB_API_BASE = "https://api.github.com"
    DEFAULT_BRANCH = "main"
    
    @classmethod
    def get_settings(cls) -> Dict:
        """Get all settings as dictionary"""
        return {
            key: getattr(cls, key)
            for key in dir(cls)
            if not key.startswith('_') and not callable(getattr(cls, key))
        }
    
    @classmethod
    def update_setting(cls, key: str, value: any):
        """Update a setting"""
        if hasattr(cls, key):
            setattr(cls, key, value)
        else:
            raise ValueError(f"Setting not found: {key}")