"""
Data Operations Tools for SuperNjagu Agent
Data processing, analysis, and transformation
"""

import json
import csv
import pandas as pd
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional, Any
import re


class DataOperations:
    """Advanced data processing toolkit"""
    
    def __init__(self):
        pass
    
    def parse_json(self, data: str) -> Dict[str, Any]:
        """Parse JSON data"""
        try:
            parsed = json.loads(data)
            return {"success": True, "data": parsed}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def to_json(self, data: Any) -> Dict[str, Any]:
        """Convert data to JSON"""
        try:
            json_str = json.dumps(data, indent=2)
            return {"success": True, "json": json_str}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def parse_csv(self, csv_data: str, delimiter: str = ",") -> Dict[str, Any]:
        """Parse CSV data"""
        try:
            reader = csv.reader(csv_data.splitlines(), delimiter=delimiter)
            headers = next(reader)
            rows = list(reader)
            
            data = []
            for row in rows:
                row_dict = dict(zip(headers, row))
                data.append(row_dict)
            
            return {"success": True, "headers": headers, "data": data}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def to_csv(self, data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Convert data to CSV"""
        try:
            if not data:
                return {"success": False, "error": "No data to convert"}
            
            headers = list(data[0].keys())
            output = []
            output.append(",".join(headers))
            
            for row in data:
                values = [str(row.get(h, "")) for h in headers]
                output.append(",".join(values))
            
            csv_str = "\n".join(output)
            return {"success": True, "csv": csv_str}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def parse_xml(self, xml_data: str) -> Dict[str, Any]:
        """Parse XML data"""
        try:
            root = ET.fromstring(xml_data)
            
            def xml_to_dict(element):
                result = {}
                for child in element:
                    if len(child) > 0:
                        result[child.tag] = xml_to_dict(child)
                    else:
                        result[child.tag] = child.text
                return result
            
            data = xml_to_dict(root)
            return {"success": True, "data": data}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def filter_data(self, data: List[Dict], field: str, value: Any) -> Dict[str, Any]:
        """Filter data by field value"""
        try:
            filtered = [item for item in data if item.get(field) == value]
            return {"success": True, "data": filtered, "count": len(filtered)}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def sort_data(self, data: List[Dict], field: str, reverse: bool = False) -> Dict[str, Any]:
        """Sort data by field"""
        try:
            sorted_data = sorted(data, key=lambda x: x.get(field, ""), reverse=reverse)
            return {"success": True, "data": sorted_data}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def aggregate_data(self, data: List[Dict], field: str, operation: str) -> Dict[str, Any]:
        """Aggregate data (sum, avg, count, min, max)"""
        try:
            values = [item.get(field, 0) for item in data if field in item]
            
            if not values:
                return {"success": False, "error": "No values to aggregate"}
            
            if operation == "sum":
                result = sum(values)
            elif operation == "avg":
                result = sum(values) / len(values)
            elif operation == "count":
                result = len(values)
            elif operation == "min":
                result = min(values)
            elif operation == "max":
                result = max(values)
            else:
                return {"success": False, "error": f"Unknown operation: {operation}"}
            
            return {"success": True, "operation": operation, "result": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def transform_data(self, data: List[Dict], transformations: Dict[str, str]) -> Dict[str, Any]:
        """Transform data with custom transformations"""
        try:
            transformed = []
            
            for item in data:
                new_item = item.copy()
                for field, transformation in transformations.items():
                    if field in new_item:
                        value = new_item[field]
                        
                        # Simple transformations
                        if transformation == "uppercase":
                            new_item[field] = str(value).upper()
                        elif transformation == "lowercase":
                            new_item[field] = str(value).lower()
                        elif transformation == "strip":
                            new_item[field] = str(value).strip()
                        elif transformation.startswith("multiply_"):
                            factor = float(transformation.split("_")[1])
                            new_item[field] = float(value) * factor
                
                transformed.append(new_item)
            
            return {"success": True, "data": transformed}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def merge_data(self, data1: List[Dict], data2: List[Dict], key: str) -> Dict[str, Any]:
        """Merge two datasets on a key field"""
        try:
            merged = []
            dict2 = {item[key]: item for item in data2 if key in item}
            
            for item1 in data1:
                if key in item1 and item1[key] in dict2:
                    merged_item = {**item1, **dict2[item1[key]]}
                    merged.append(merged_item)
            
            return {"success": True, "data": merged, "count": len(merged)}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def extract_text_patterns(self, text: str, pattern: str) -> Dict[str, Any]:
        """Extract text using regex patterns"""
        try:
            matches = re.findall(pattern, text)
            return {"success": True, "matches": matches, "count": len(matches)}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def clean_text(self, text: str, operations: List[str]) -> Dict[str, Any]:
        """Clean text with various operations"""
        try:
            result = text
            
            for op in operations:
                if op == "strip":
                    result = result.strip()
                elif op == "lowercase":
                    result = result.lower()
                elif op == "uppercase":
                    result = result.upper()
                elif op == "remove_extra_spaces":
                    result = re.sub(r'\s+', ' ', result)
                elif op == "remove_newlines":
                    result = result.replace('\n', ' ')
                elif op == "remove_special_chars":
                    result = re.sub(r'[^a-zA-Z0-9\s]', '', result)
            
            return {"success": True, "cleaned": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def analyze_data(self, data: List[Dict]) -> Dict[str, Any]:
        """Analyze data and provide statistics"""
        try:
            if not data:
                return {"success": False, "error": "No data to analyze"}
            
            analysis = {
                "total_records": len(data),
                "fields": list(data[0].keys()),
                "field_types": {},
                "null_counts": {}
            }
            
            for field in analysis["fields"]:
                values = [item.get(field) for item in data if field in item]
                analysis["field_types"][field] = type(values[0]).__name__ if values else "unknown"
                analysis["null_counts"][field] = len([v for v in values if v is None or v == ""])
            
            return {"success": True, "analysis": analysis}
        except Exception as e:
            return {"success": False, "error": str(e)}


if __name__ == "__main__":
    # Test data operations
    data_ops = DataOperations()
    
    # Test JSON parsing
    json_data = '{"name": "SuperNjagu", "version": "1.0"}'
    result = data_ops.parse_json(json_data)
    print(result)