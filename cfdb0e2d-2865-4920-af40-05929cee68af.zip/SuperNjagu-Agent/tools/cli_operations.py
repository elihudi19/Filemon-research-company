"""
CLI Operations Tools for SuperNjagu Agent
Command execution and terminal operations
"""

import subprocess
import shlex
import os
from typing import Dict, List, Optional, Any
import signal
import threading


class CLIOperations:
    """Advanced CLI operations toolkit"""
    
    def __init__(self, workspace: str = "/workspace"):
        self.workspace = workspace
        self.running_processes = {}
    
    def execute_command(self, command: str, cwd: Optional[str] = None, 
                        timeout: int = 300, env: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """
        Execute shell command synchronously
        """
        working_dir = cwd or self.workspace
        
        try:
            # Prepare environment
            process_env = os.environ.copy()
            if env:
                process_env.update(env)
            
            # Execute command
            result = subprocess.run(
                command,
                shell=True,
                cwd=working_dir,
                env=process_env,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "command": command
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Command timeout", "command": command}
        except Exception as e:
            return {"success": False, "error": str(e), "command": command}
    
    def execute_async(self, command: str, cwd: Optional[str] = None,
                     session_name: str = "default") -> Dict[str, Any]:
        """
        Execute command asynchronously (non-blocking)
        """
        working_dir = cwd or self.workspace
        
        try:
            process = subprocess.Popen(
                command,
                shell=True,
                cwd=working_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            self.running_processes[session_name] = process
            
            return {
                "success": True,
                "session_name": session_name,
                "pid": process.pid,
                "message": "Command started in background"
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def check_process(self, session_name: str) -> Dict[str, Any]:
        """Check status of running process"""
        if session_name not in self.running_processes:
            return {"success": False, "error": "Process not found"}
        
        process = self.running_processes[session_name]
        
        return {
            "success": True,
            "running": process.poll() is None,
            "returncode": process.poll(),
            "pid": process.pid
        }
    
    def kill_process(self, session_name: str) -> Dict[str, Any]:
        """Kill running process"""
        if session_name not in self.running_processes:
            return {"success": False, "error": "Process not found"}
        
        try:
            process = self.running_processes[session_name]
            process.terminate()
            process.wait(timeout=5)
            del self.running_processes[session_name]
            return {"success": True, "message": "Process terminated"}
        except subprocess.TimeoutExpired:
            process.kill()
            del self.running_processes[session_name]
            return {"success": True, "message": "Process force killed"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_process_output(self, session_name: str) -> Dict[str, Any]:
        """Get output from process"""
        if session_name not in self.running_processes:
            return {"success": False, "error": "Process not found"}
        
        process = self.running_processes[session_name]
        
        try:
            stdout, stderr = process.communicate(timeout=1)
            return {
                "success": True,
                "stdout": stdout,
                "stderr": stderr
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Process still running"}
    
    def chain_commands(self, commands: List[str], cwd: Optional[str] = None) -> Dict[str, Any]:
        """
        Chain multiple commands with &&
        """
        chained_command = " && ".join(commands)
        return self.execute_command(chained_command, cwd)
    
    def pipe_commands(self, commands: List[str], cwd: Optional[str] = None) -> Dict[str, Any]:
        """
        Pipe commands with |
        """
        piped_command = " | ".join(commands)
        return self.execute_command(piped_command, cwd)
    
    def run_python_script(self, script_path: str, args: List[str] = None,
                          cwd: Optional[str] = None) -> Dict[str, Any]:
        """Run Python script"""
        cmd = ["python", script_path]
        if args:
            cmd.extend(args)
        
        command = " ".join(shlex.quote(arg) for arg in cmd)
        return self.execute_command(command, cwd)
    
    def install_package(self, package: str, package_manager: str = "pip") -> Dict[str, Any]:
        """Install Python package"""
        if package_manager == "pip":
            command = f"pip install {package}"
        elif package_manager == "npm":
            command = f"npm install {package}"
        else:
            return {"success": False, "error": f"Unknown package manager: {package_manager}"}
        
        return self.execute_command(command)
    
    def git_clone(self, repository_url: str, destination: str = "") -> Dict[str, Any]:
        """Clone git repository"""
        if destination:
            command = f"git clone {repository_url} {destination}"
        else:
            command = f"git clone {repository_url}"
        
        return self.execute_command(command)
    
    def git_status(self, cwd: Optional[str] = None) -> Dict[str, Any]:
        """Get git status"""
        return self.execute_command("git status", cwd)
    
    def git_commit(self, message: str, cwd: Optional[str] = None) -> Dict[str, Any]:
        """Commit changes"""
        return self.execute_command(f'git commit -m "{message}"', cwd)
    
    def git_push(self, branch: str = "main", cwd: Optional[str] = None) -> Dict[str, Any]:
        """Push to remote"""
        return self.execute_command(f"git push origin {branch}", cwd)
    
    def cleanup_processes(self):
        """Clean up all running processes"""
        for session_name in list(self.running_processes.keys()):
            self.kill_process(session_name)


if __name__ == "__main__":
    # Test CLI operations
    cli_ops = CLIOperations()
    result = cli_ops.execute_command("echo 'Hello from SuperNjagu Agent!'")
    print(result)