"""
File Operations Tools for SuperNjagu Agent
Comprehensive file system operations
"""

import os
import shutil
import json
from typing import Dict, List, Optional, Any
from pathlib import Path


class FileOperations:
    """Advanced file operations toolkit"""
    
    def __init__(self, workspace: str = "/workspace"):
        self.workspace = workspace
    
    def create_file(self, file_path: str, content: str) -> Dict[str, Any]:
        """Create a file with content"""
        full_path = os.path.join(self.workspace, file_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        
        try:
            with open(full_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return {
                "success": True,
                "path": full_path,
                "size": len(content),
                "message": f"File created: {file_path}"
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def read_file(self, file_path: str) -> Dict[str, Any]:
        """Read file contents"""
        full_path = os.path.join(self.workspace, file_path)
        
        if not os.path.exists(full_path):
            return {"success": False, "error": f"File not found: {file_path}"}
        
        try:
            with open(full_path, 'r', encoding='utf-8') as f:
                content = f.read()
            return {
                "success": True,
                "content": content,
                "size": len(content),
                "path": full_path
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def update_file(self, file_path: str, old_str: str, new_str: str) -> Dict[str, Any]:
        """Update specific text in file"""
        full_path = os.path.join(self.workspace, file_path)
        
        if not os.path.exists(full_path):
            return {"success": False, "error": "File not found"}
        
        try:
            with open(full_path, 'r') as f:
                content = f.read()
            
            if old_str not in content:
                return {"success": False, "error": "Old string not found in file"}
            
            new_content = content.replace(old_str, new_str)
            
            with open(full_path, 'w') as f:
                f.write(new_content)
            
            return {"success": True, "message": "File updated successfully"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def delete_file(self, file_path: str) -> Dict[str, Any]:
        """Delete a file"""
        full_path = os.path.join(self.workspace, file_path)
        
        if not os.path.exists(full_path):
            return {"success": False, "error": "File not found"}
        
        try:
            os.remove(full_path)
            return {"success": True, "message": f"File deleted: {file_path}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def list_directory(self, dir_path: str = "") -> Dict[str, Any]:
        """List contents of directory"""
        full_path = os.path.join(self.workspace, dir_path) if dir_path else self.workspace
        
        if not os.path.exists(full_path):
            return {"success": False, "error": "Directory not found"}
        
        try:
            items = []
            for item in os.listdir(full_path):
                item_path = os.path.join(full_path, item)
                items.append({
                    "name": item,
                    "type": "directory" if os.path.isdir(item_path) else "file",
                    "size": os.path.getsize(item_path) if os.path.isfile(item_path) else 0
                })
            return {"success": True, "items": items, "path": full_path}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def create_directory(self, dir_path: str) -> Dict[str, Any]:
        """Create directory"""
        full_path = os.path.join(self.workspace, dir_path)
        
        try:
            os.makedirs(full_path, exist_ok=True)
            return {"success": True, "message": f"Directory created: {dir_path}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def copy_file(self, source: str, destination: str) -> Dict[str, Any]:
        """Copy file"""
        source_path = os.path.join(self.workspace, source)
        dest_path = os.path.join(self.workspace, destination)
        
        if not os.path.exists(source_path):
            return {"success": False, "error": "Source file not found"}
        
        try:
            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
            shutil.copy2(source_path, dest_path)
            return {"success": True, "message": f"File copied to: {destination}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def move_file(self, source: str, destination: str) -> Dict[str, Any]:
        """Move file"""
        source_path = os.path.join(self.workspace, source)
        dest_path = os.path.join(self.workspace, destination)
        
        if not os.path.exists(source_path):
            return {"success": False, "error": "Source file not found"}
        
        try:
            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
            shutil.move(source_path, dest_path)
            return {"success": True, "message": f"File moved to: {destination}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def search_files(self, pattern: str, directory: str = "") -> Dict[str, Any]:
        """Search for files matching pattern"""
        search_dir = os.path.join(self.workspace, directory) if directory else self.workspace
        
        try:
            matches = []
            for root, dirs, files in os.walk(search_dir):
                for file in files:
                    if pattern.lower() in file.lower():
                        matches.append(os.path.join(root, search_dir, file))
            return {"success": True, "matches": matches, "pattern": pattern}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_file_info(self, file_path: str) -> Dict[str, Any]:
        """Get detailed file information"""
        full_path = os.path.join(self.workspace, file_path)
        
        if not os.path.exists(full_path):
            return {"success": False, "error": "File not found"}
        
        try:
            stat = os.stat(full_path)
            return {
                "success": True,
                "path": full_path,
                "size": stat.st_size,
                "created": stat.st_ctime,
                "modified": stat.st_mtime,
                "accessed": stat.st_atime,
                "is_file": os.path.isfile(full_path),
                "is_dir": os.path.isdir(full_path)
            }
        except Exception as e:
            return {"success": False, "error": str(e)}


if __name__ == "__main__":
    # Test file operations
    file_ops = FileOperations()
    result = file_ops.create_file("test.txt", "Hello from SuperNjagu Agent!")
    print(result)