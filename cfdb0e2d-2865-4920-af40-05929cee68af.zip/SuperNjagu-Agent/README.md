# SuperNjagu Agent 🚀

**High-Performance Autonomous AI Agent** - A comprehensive autonomous agent capable of executing complex tasks across multiple domains including file operations, web scraping, command execution, data processing, and autonomous problem-solving.

![SuperNjagu](https://img.shields.io/badge/version-1.0.0-blue)
![Python](https://img.shields.io/badge/python-3.11+-green)
![License](https://img.shields.io/badge/license-MIT-yellow)

## 🌟 Features

### Core Capabilities
- **🤖 Autonomous Task Execution**: Break down and execute complex tasks autonomously
- **📁 Advanced File Operations**: Create, read, modify, and manage files
- **🌐 Web Operations**: Search, scrape, and interact with web pages
- **⚡ CLI Operations**: Execute shell commands synchronously and asynchronously
- **📊 Data Processing**: Parse, transform, and analyze data (JSON, CSV, XML)
- **🔄 Workflow Management**: Intelligent todo.md tracking and task management
- **🎯 Interactive Mode**: Command-line interface for direct interaction

### Key Highlights
- ✅ **Fully Autonomous**: Self-maintaining todo.md system
- ✅ **Modular Architecture**: Easy to extend with new tools
- ✅ **High Performance**: Optimized for speed and efficiency
- ✅ **Error Handling**: Robust error recovery and retry mechanisms
- ✅ **Session Tracking**: Comprehensive session and progress management
- ✅ **Production Ready**: Well-documented and tested

## 🛠️ Installation

### Prerequisites
- Python 3.11 or higher
- pip package manager
- Git (for deployment)

### Quick Install

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/SuperNjagu-Agent.git
cd SuperNjagu-Agent

# Install dependencies
pip install -r requirements.txt

# Run the agent
python main.py
```

### Development Setup

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install development dependencies
pip install -r requirements.txt

# Run tests
pytest tests/
```

## 🚀 Quick Start

### Interactive Mode

```bash
python main.py
```

This launches the interactive mode where you can:
- Enter tasks for autonomous execution
- Execute file operations directly
- Run shell commands
- Check agent status

### Programmatic Usage

```python
from main import SuperNjaguMain
import asyncio

# Create agent instance
agent = SuperNjaguMain(workspace="/workspace")

# Run a task
result = asyncio.run(agent.run_task("Create a Python web scraper"))

# Check status
status = agent.get_status()
print(status)
```

### Using Tools Directly

```python
from tools.file_operations import FileOperations
from tools.cli_operations import CLIOperations
from tools.web_operations import WebOperations
from tools.data_operations import DataOperations

# File operations
file_ops = FileOperations()
file_ops.create_file("hello.txt", "Hello World!")

# CLI operations
cli_ops = CLIOperations()
result = cli_ops.execute_command("ls -la")

# Web operations
web_ops = WebOperations()
results = asyncio.run(web_ops.web_search("Python tutorials"))

# Data operations
data_ops = DataOperations()
json_data = data_ops.parse_json('{"key": "value"}')
```

## 📖 Documentation

### Project Structure

```
SuperNjagu-Agent/
├── src/
│   └── agent.py              # Core agent implementation
├── tools/
│   ├── file_operations.py    # File system operations
│   ├── web_operations.py     # Web search and scraping
│   ├── cli_operations.py     # Command execution
│   └── data_operations.py    # Data processing
├── config/
│   └── settings.py           # Configuration settings
├── tests/                    # Test suite
├── docs/                     # Documentation
├── main.py                   # Entry point
├── requirements.txt          # Python dependencies
├── README.md                 # This file
└── .gitignore               # Git ignore rules
```

### Core Components

#### 1. SuperNjaguAgent
Main agent class that orchestrates autonomous execution.

**Key Methods:**
- `execute_autonomous(task_description)` - Run task autonomously
- `update_todo(tasks)` - Update task list
- `get_next_task()` - Get next incomplete task
- `get_status()` - Get agent status

#### 2. FileOperations
Comprehensive file system operations.

**Capabilities:**
- Create, read, update, delete files
- Directory management
- File search and copying
- File information retrieval

#### 3. WebOperations
Web interaction capabilities.

**Capabilities:**
- Web search
- Webpage scraping
- JSON data fetching
- File downloads
- Browser simulation

#### 4. CLIOperations
Command execution and terminal operations.

**Capabilities:**
- Synchronous and asynchronous command execution
- Process management
- Command chaining and piping
- Git operations

#### 5. DataOperations
Data processing and analysis.

**Capabilities:**
- JSON, CSV, XML parsing
- Data filtering and sorting
- Data aggregation
- Text processing and cleaning
- Data analysis

## 💡 Use Cases

### 1. Web Scraping
```python
result = asyncio.run(agent.run_task(
    "Scrape product prices from e-commerce site and save to CSV"
))
```

### 2. Data Analysis
```python
result = asyncio.run(agent.run_task(
    "Analyze sales data and generate monthly report"
))
```

### 3. Automation
```python
result = asyncio.run(agent.run_task(
    "Automate daily backup process and send email notification"
))
```

### 4. Code Generation
```python
result = asyncio.run(agent.run_task(
    "Create a REST API with Flask for task management"
))
```

## 🎯 Autonomous Workflow

The agent follows a systematic approach:

1. **Task Analysis**: Understand and break down the task
2. **Planning**: Create detailed todo.md with subtasks
3. **Execution**: Execute tasks step by step
4. **Tracking**: Update progress in real-time
5. **Verification**: Validate results at each step
6. **Completion**: Mark tasks complete and report results

## 🔧 Configuration

Edit `config/settings.py` to customize:

```python
# Agent settings
AGENT_NAME = "SuperNjagu Agent"
WORKSPACE = "/workspace"

# Timeout settings
COMMAND_TIMEOUT = 300
WEB_REQUEST_TIMEOUT = 30

# Web settings
MAX_SEARCH_RESULTS = 10
```

## 🧪 Testing

```bash
# Run all tests
pytest tests/

# Run specific test
pytest tests/test_agent.py

# Run with coverage
pytest --cov=src tests/
```

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👥 Authors

- **SuperNjagu AI Team** - Initial work

## 🙏 Acknowledgments

- Inspired by Cursor AI and SuperNinja AI
- Built with modern Python async/await patterns
- Powered by aiohttp, BeautifulSoup, and pandas

## 📞 Support

For support and questions:
- Open an issue on GitHub
- Check the documentation in `/docs`
- Review the examples in `/examples`

## 🌟 Star History

If you find this project useful, please consider giving it a star ⭐️ on GitHub!

---

**SuperNjagu Agent** - Making autonomous AI accessible and powerful 🚀